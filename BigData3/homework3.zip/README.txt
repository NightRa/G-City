Ilan Godik ; ilan3580@gmail.com ; 316315332
Tony Tannous ; ttannous@campus.haifa.ac.il ; 205735046
Charlie Mubariky ; Charlie_mabariky.1996@hotmail.com ; 316278118
Yuval Alfassi ; u67v67@gmail.com ; 318401015
Gil Henkin ; gil7788@gmail.com ; 315046805