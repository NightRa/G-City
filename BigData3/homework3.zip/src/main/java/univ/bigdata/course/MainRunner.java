package univ.bigdata.course;

public class MainRunner {

    public static void main(String[] args) {
        SparkMain.main(args);
    }
}
